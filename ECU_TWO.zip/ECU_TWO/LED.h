/*
 * LED.h
 *
 *  Created on: ??�/??�/????
 *      Author: Twins
 */

#ifndef LED_H_
#define LED_H_

void Init_ECU2 (void);
void Capture_Data (void);
void Check_COND_LED_RED (void);
void Check_COND_LED_BLUE (void);

#endif /* LED_H_ */
