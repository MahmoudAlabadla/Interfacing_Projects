/*
 * Terminal.h
 *
 *  Created on: 24/03/2021
 *      Author: Mahmoud Ayman
 */

#ifndef TERMINAL_H_
#define TERMINAL_H_


void Init_ECU1 (void);
void Receive_From_Terminal (void);
void Send_Data (void);

#endif /* TERMINAL_H_ */
